
from gamelib import *

game = Game(800,600,"Game")
stars=[]
fireballs=[]
arrows=[]
fireball=Animation("Project Images\\Character Sprites\\monsterM\\attack2.info.effect_",9,game)
arrow=Animation("Project Images\\Character Sprites\\monsterA\\attack1.info.ball_",7,game)
star=Animation("Project Images\\Character Sprites\\monsterT\\attack2.info.ball_",2,game)

controls=Image("Project Images\\controls.jpg",game)
background=Image("Project Images\\background.jpg",game)
splashscreen=Image("Project Images\\Splashscreen.jpg",game)
deathscreen=Image("Project Images\\DeathScreen.jpg",game)

fireballhit=Animation("Project Images\\Character Sprites\\monsterM\\attack2.info.hit_",7,game)

platform=Image("Project Images\\platform.png",game)
platform2=Image("Project Images\\platform.png",game)
platform3=Image("Project Images\\platform.png",game)

playerfly=Animation("Project Images\\Character Sprites\\hero\\flyright_",15,game)

irenashoot=Animation("Project Images\\Character Sprites\\monsterA\\attack1_",25,game)
eckhartattack=Animation("Project Images\\Character Sprites\\monsterT\\attack2_",23,game)
ozattack=Animation("Project Images\\Character Sprites\\monsterM\\attack2_",23,game)


splashscreen.draw()
game.update(1)
game.wait(K_SPACE)
controls.draw()
game.update(1)
game.wait(K_SPACE)

for times in range(10):
    arrows.append(Animation("Project Images\\Character Sprites\\monsterA\\attack1.info.ball_",7,game))
    fireballs.append(Animation("Project Images\\Character Sprites\\monsterM\\attack2.info.effect_",9,game))
    stars.append(Animation("Project Images\\Character Sprites\\monsterT\\attack2.info.ball_",2,game))
for f in fireballs:
    x=randint(800,1000)
    y=randint(400,600)
    f.setSpeed(5,90)
    f.moveTo(x,y)
for a in arrows:
    x=randint(800,1000)
    y=randint(200,400)
    a.setSpeed(7,90)
    a.moveTo(x,y)
for s in stars:
    x=randint(800,1000)
    y=randint(0,200)
    s.setSpeed(4,90)
    s.moveTo(x,y)
playerfly.health=100
eckhartattack.moveTo(700,100)
irenashoot.moveTo(700,300)
ozattack.moveTo(700,500)
time=0
potion=3
while not game.over:
    game.processInput()

    
    time+=.5

    background.draw()
    eckhartattack.nextFrame()
    irenashoot.nextFrame()
    ozattack.nextFrame()
    
    playerfly.nextFrame()
    
    platform.draw()
    platform.moveTo(eckhartattack.x,eckhartattack.y+45)
    platform2.draw()
    platform2.moveTo(irenashoot.x,irenashoot.y+43)
    platform3.draw()
    platform3.moveTo(ozattack.x,ozattack.y+43)
    for f in fireballs:
        f.move()
        if f.collidedWith(playerfly):
            x=randint(800,1000)
            y=randint(400,600)
            f.moveTo(x,y)
            playerfly.health-=10
        if f.isOffScreen("left"):
            x=randint(800,1000)
            y=randint(400,600)
            f.moveTo(x,y)

            
    for a in arrows:
        a.move()
        if a.collidedWith(playerfly):
            x=randint(800,1000)
            y=randint(200,400)
            playerfly.health-=10
            a.moveTo(x,y)
        if a.isOffScreen("left"):
            x=randint(800,1000)
            y=randint(200,400)
            a.moveTo(x,y)

    for s in stars:
        s.move()
        if s.collidedWith(playerfly):
            x=randint(800,1000)
            y=randint(0,200)
            playerfly.health-=10
            s.moveTo(x,y)
        if s.isOffScreen("left"):
            x=randint(800,1000)
            y=randint(0,200)
            s.moveTo(x,y)

    if playerfly.isOffScreen():
        playerfly.moveTo(400,300)

    

    if keys.Pressed[K_LEFT]:
        playerfly.moveX(-6)

    elif keys.Pressed[K_RIGHT] and keys.Pressed[K_UP]:
        playerfly.moveX(6)
        playerfly.moveY(-6)
     
    elif keys.Pressed[K_LEFT] and keys.Pressed[K_UP]:
        playerfly.moveX(-6)
        playerfly.moveY(-6)

    elif keys.Pressed[K_RIGHT]:
        playerfly.moveX(6)


    elif keys.Pressed[K_UP]:
        playerfly.moveY(-6)

    elif keys.Pressed[K_RIGHT] and keys.Pressed[K_DOWN]:
        playerfly.moveX(6)
        playerfly.moveY(6)
        
    elif keys.Pressed[K_LEFT] and keys.Pressed[K_DOWN]:
        playerfly.moveX(-6)
        playerfly.moveY(6)
        
    elif keys.Pressed[K_DOWN]:
        playerfly.moveY(6)

    if keys.Pressed[K_z] and potion>0:
        potion-=1
        playerfly.health+=50

        
    if playerfly.health<=0:
        deathscreen.draw()
        game.update(1)
        game.wait[K_ESCAPE]
        game.over=True

    game.drawText("Health: "+str(playerfly.health),5,5)
    game.drawText("Score: "+str(time),5,20)
    game.drawText("Potions: "+str(potion),5,35)
    
    
    game.update(30)
game.quit()
